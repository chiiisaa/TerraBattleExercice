#pragma once

enum GameSate { Menu, GamePlayState, LevelState, TutoState };
